
import Chatmaior from './Chatmaior'
import Chatmenor from './Chatmenor'
import estilo from './App.module.css'

function App() {

  return (
    <div className={estilo.main}>
        <Chatmaior/>
        <Chatmenor/>

    </div>
  )
}

export default App
