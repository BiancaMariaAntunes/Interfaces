import estilo from './Chatmaior.module.css'


function Chatmaior(){
    return(
        <header className={estilo.principal}>
            <p className={estilo.Letra}> 
                Atendimento
            </p>
        </header>

    )
}

export default Chatmaior;