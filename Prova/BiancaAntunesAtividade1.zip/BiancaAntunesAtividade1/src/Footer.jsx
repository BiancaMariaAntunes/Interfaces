import objeto from './Footer.module.css'

function Footer(){
     console.log(objeto)
    return (
        <footer className={objeto.estilo}>
        </footer>
    )
}

export default Footer;