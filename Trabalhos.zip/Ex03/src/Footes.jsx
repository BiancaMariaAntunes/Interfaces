import objeto from './Footes.module.css'

function Footes(){
     console.log(objeto)
    return (
        <footer className={objeto.estilo}>
        </footer>
    )
}

export default Footes;