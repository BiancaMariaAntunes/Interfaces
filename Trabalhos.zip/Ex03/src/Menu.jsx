import estilo from './Menu.module.css'


function Menu(props){

    return(
        <div className={estilo.principal}>      
        </div>

    )
}

export default Menu;