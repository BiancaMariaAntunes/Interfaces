import estilo from './Post.module.css'


function Post(props){

    return(
        <div className={estilo.principal}>
            <p className={estilo.Letra}> 
                Section
            </p>

        
        </div>

    )
}

export default Post;