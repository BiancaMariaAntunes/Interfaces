import estilo from './Menu.module.css'


function Menu(props){

    return(
        <div className={estilo.principal}>
            <p className={estilo.Letra}> 
                Menu
            </p>
        
        </div>

    )
}

export default Menu;