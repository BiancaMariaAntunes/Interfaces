import estilo from './Teclado.module.css'


function Teclado(){
    return(
        <section className={estilo.principal}>
            <p className={estilo.Letra}> 
                
            </p>

        
        </section>

    )
}

export default Teclado;